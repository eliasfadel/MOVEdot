---
name: Bug report
about: Something not working as expected? Let us look into it
labels: bug
---

## Bug description

_Please describe._  
_If this affects the front-end, screenshots would be of great help._

## How to reproduce

1.
2.
3.

## Additional context
