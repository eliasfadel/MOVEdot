---
'@gitbook/react-openapi': patch
---

Fixed scalar api client routing
