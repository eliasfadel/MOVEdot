---
'@gitbook/react-openapi': patch
---

Bump @scalar/api-client-react version
