---
'gitbook': patch
---

Smoother tab transition for sections
