---
'@gitbook/cache-do': patch
---

Disable cloudflare observability in production
