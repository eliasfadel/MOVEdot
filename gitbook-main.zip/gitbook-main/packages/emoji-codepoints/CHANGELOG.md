# @gitbook/emoji-codepoints

## 0.2.0

### Minor Changes

-   57adb3e: Second release to fix publishing with changeset

## 0.1.0

### Minor Changes

-   5f8a8fe: Initial release
