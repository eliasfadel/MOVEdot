# `@gitbook/react-math`

React component to render a Math formula. It uses KaTeX when possible and fallbacks to MathJaX if needed.
