# @gitbook/cache-do

## 0.1.0

### Minor Changes

-   9b8d519: Experiment with optimizing billable duration in Cloudflare by using multiple RPC sessions instead of one
-   636b868: First version of a new cache backend powered by Cloudflare Durable Objects

### Patch Changes

-   56f5fa1: Enable Workers observability with a sampling of 0.1
