# @gitbook/react-contentkit

## 0.5.1

### Patch Changes

-   0f1565c: Fix rendering of webframe with SSR causing wrong communication between frame and renderer

## 0.5.0

### Minor Changes

-   3445db4: Fix files published in the NPM packages by defining "files" in "package.json"

## 0.4.0

### Minor Changes

-   24cd72e: Fix changeset CI workflow

## 0.3.0

### Minor Changes

-   de747b7: Publish to NPM with JS files and TypeScript declaration files

## 0.2.0

### Minor Changes

-   57adb3e: Second release to fix publishing with changeset

## 0.1.0

### Minor Changes

-   5f8a8fe: Initial release
