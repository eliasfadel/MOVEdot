// Needed because of https://github.com/oven-sh/bun/issues/358

/// <reference lib="dom" />
/// <reference lib="dom.iterable" />
