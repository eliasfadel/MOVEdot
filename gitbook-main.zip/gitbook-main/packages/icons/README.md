# `@gitbook/icons`

Icon sets useed in GitBook content.

## Usage

```tsx
import { Icon } from '@gitbook/icons';

<Icon name="x" className={'size-5'} />;
```
