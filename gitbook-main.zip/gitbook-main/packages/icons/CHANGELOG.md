# @gitbook/icons

## 0.1.0

### Minor Changes

-   5c35f36: Initial release for `@gitbook/icons`, a package of content icons to be used for pages, documents, etc.
-   776bc31: Fix bin gitbook-icons when installed without the Pro token

### Patch Changes

-   d0f4860: Update version for static assets to fix invalid caching
-   ef9d012: Fix first run of the package in development mode
